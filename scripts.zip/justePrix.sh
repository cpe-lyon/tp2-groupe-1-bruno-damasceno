rand=$(($RANDOM%1000))
var=-1
while [ $rand -ne $var ]
do
read -p 'Entrez un nombre : ' var
if [ $var -ne $rand ]; then
if [ $var -gt $rand ]; then
	echo "Trop grand"
else
	echo "Trop petit"
fi
else
	echo "c'est gagné !"
fi
done
