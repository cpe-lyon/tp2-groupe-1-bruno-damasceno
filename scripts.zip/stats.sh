max=-100
min=100

sum=0
i=0

file=$( cat $1 | tr , "\n" )

while IFS= read -r param ; do
do
	if ! [ $(./is_number.sh $param) == 'oui' ]; then
		exit
	fi
done <<< "$file"

while IFS= read -r param ; do
do
	sum=$(($sum + $param))

	if [ $max -le $param ];then
	max=$param
	fi

	if [ $min -gt $param ]; then
	min=$param
	fi

	((i++))
done <<< "$file"

mean=$(($sum/$i))

echo "min: "$min
echo "max: "$max
echo "mean: "$mean
