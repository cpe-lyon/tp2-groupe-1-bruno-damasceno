#!/bin/bash
PASSWORD='1234'
read -s -p 'Saisir votre mot de passe : ' pwd
echo
if [ $pwd == $PASSWORD ];
then
	echo "c'est bon !"
else
	echo "c'est pas bon !"
fi

