i=1
res=1
while [ $i -le $1 ]
do
	res=$(($res*$i))
	((i++))
done
echo $res
